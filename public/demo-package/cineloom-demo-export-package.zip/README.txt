CineLoom.ai v2.5 Director Demo Export Package

Includes:
- cineloom-director-storyboard-package.pdf
- cineloom-animatic-preview.mp4
- cineloom-shot-list.csv
- cineloom-prompt-package.json
- cineloom-qa-report.pdf

This package is designed for a private Hollywood director / producer / investor demo.
